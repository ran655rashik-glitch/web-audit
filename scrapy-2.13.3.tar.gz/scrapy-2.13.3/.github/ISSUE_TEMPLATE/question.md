---
name: Question / Help
about: Ask a question about Scrapy or ask for help with your Scrapy code.
---

Thanks for taking an interest in Scrapy!

The Scrapy GitHub issue tracker is not meant for questions or help. Please ask
for help in the [Scrapy community resources](https://scrapy.org/community/)
instead.

The GitHub issue tracker's purpose is to deal with bug reports and feature
requests for the project itself.
