# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.13.x     | :white_check_mark: |
| < 2.13.x   | :x:                |

## Reporting a Vulnerability

Please report the vulnerability using https://github.com/scrapy/scrapy/security/advisories/new.
