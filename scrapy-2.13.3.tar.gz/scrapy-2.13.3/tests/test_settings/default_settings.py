TEST_DEFAULT = "defvalue"

TEST_DICT = {"key": "val"}
